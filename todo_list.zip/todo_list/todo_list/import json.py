import json
from datetime import datetime

tasks = []

# Load tasks from file
def load_tasks():
    global tasks
    try:
        with open("tasks.json", "r") as file:
            tasks = json.load(file)
    except FileNotFoundError:
        tasks = []

# Save tasks to file
def save_tasks():
    with open("tasks.json", "w") as file:
        json.dump(tasks, file)

# Function to display the to-do list
def display_tasks():
    if not tasks:
        print("Your to-do list is empty.")
    else:
        print("To-Do List:")
        pending_tasks = [task for task in tasks if not task["completed"]]
        completed_tasks = [task for task in tasks if task["completed"]]

        for i, task in enumerate(pending_tasks, start=1):
            status = "Done" if task["completed"] else "Not Done"
            due_date = task["due_date"] if task["due_date"] else "No due date"
            print(f"{i}. {task['task']} - Priority: {task['priority']} - Due: {due_date} ({status})")

        if completed_tasks:
            print("\nCompleted Tasks:")
            for i, task in enumerate(completed_tasks, start=1):
                due_date = task["due_date"] if task["due_date"] else "No due date"
                print(f"{i}. {task['task']} - Priority: {task['priority']} - Due: {due_date} (Done)")

# Function to add a task to the to-do list
def add_task(task_name, priority, due_date):
    task = {
        "task": task_name,
        "priority": priority,
        "due_date": due_date,
        "completed": False
    }
    tasks.append(task)
    save_tasks()
    print(f"Task '{task_name}' added to your to-do list.")

# Function to edit a task
def edit_task(task_number, task_name, priority, due_date):
    if 1 <= task_number <= len(tasks):
        tasks[task_number - 1].update({
            "task": task_name,
            "priority": priority,
            "due_date": due_date
        })
        save_tasks()
        print(f"Task {task_number} has been updated.")
    else:
        print("Invalid task number. Please enter a valid task number.")

# Function to mark a task as completed
def mark_completed(task_number):
    if 1 <= task_number <= len(tasks):
        tasks[task_number - 1]["completed"] = True
        save_tasks()
        print(f"Task {task_number} marked as completed.")
    else:
        print("Invalid task number. Please enter a valid task number.")

# Function to remove a task from the to-do list
def remove_task(task_number):
    if 1 <= task_number <= len(tasks):
        removed_task = tasks.pop(task_number - 1)
        save_tasks()
        print(f"Task '{removed_task['task']}' removed from your to-do list.")
    else:
        print("Invalid task number. Please enter a valid task number.")

# Function to search for tasks
def search_tasks(keyword):
    results = [task for task in tasks if keyword.lower() in task["task"].lower()]
    if results:
        print("Search Results:")
        for i, task in enumerate(results, start=1):
            status = "Done" if task["completed"] else "Not Done"
            due_date = task["due_date"] if task["due_date"] else "No due date"
            print(f"{i}. {task['task']} - Priority: {task['priority']} - Due: {due_date} ({status})")
    else:
        print(f"No tasks found containing the keyword '{keyword}'.")

# Function to sort tasks
def sort_tasks(criteria):
    if criteria == "priority":
        tasks.sort(key=lambda x: x["priority"])
    elif criteria == "due_date":
        tasks.sort(key=lambda x: (x["due_date"] is None, x["due_date"]))
    elif criteria == "status":
        tasks.sort(key=lambda x: x["completed"])
    else:
        print("Invalid sort criteria. Please choose from 'priority', 'due_date', or 'status'.")
    save_tasks()
    print(f"Tasks sorted by {criteria}.")

# Main program loop
def main():
    load_tasks()
    while True:
        print("\nOptions:")
        print("1. Display to-do list")
        print("2. Add a task")
        print("3. Edit a task")
        print("4. Mark a task as completed")
        print("5. Remove a task")
        print("6. Search for tasks")
        print("7. Sort tasks")
        print("8. Quit")
        choice = input("Enter your choice: ")

        if choice == '1':
            display_tasks()
        elif choice == '2':
            task_name = input("Enter the task: ")
            priority = input("Enter the priority (Low, Medium, High): ")
            due_date = input("Enter the due date (YYYY-MM-DD) or press Enter to skip: ")
            due_date = due_date if due_date else None
            if due_date:
                try:
                    datetime.strptime(due_date, "%Y-%m-%d")
                except ValueError:
                    print("Invalid date format. Task not added.")
                    continue
            add_task(task_name, priority, due_date)
        elif choice == '3':
            display_tasks()
            task_number = int(input("Enter the task number to edit: "))
            task_name = input("Enter the new task name: ")
            priority = input("Enter the new priority (Low, Medium, High): ")
            due_date = input("Enter the new due date (YYYY-MM-DD) or press Enter to skip: ")
            due_date = due_date if due_date else None
            if due_date:
                try:
                    datetime.strptime(due_date, "%Y-%m-%d")
                except ValueError:
                    print("Invalid date format. Task not edited.")
                    continue
            edit_task(task_number, task_name, priority, due_date)
        elif choice == '4':
            display_tasks()
            task_number = int(input("Enter the task number to mark as completed: "))
            mark_completed(task_number)
        elif choice == '5':
            display_tasks()
            task_number = int(input("Enter the task number to remove: "))
            remove_task(task_number)
        elif choice == '6':
            keyword = input("Enter the keyword to search for: ")
            search_tasks(keyword)
        elif choice == '7':
            criteria = input("Enter the sort criteria (priority, due_date, status): ")
            sort_tasks(criteria)
        elif choice == '8':
            break
        else:
            print("Invalid choice. Please enter a valid option.")

if __name__ == "__main__":
    main()